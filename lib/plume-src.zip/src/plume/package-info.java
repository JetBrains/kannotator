/**
 * <p>
 * The <tt>plume</tt> package contains the Java component of <a
 * href="http://plume-lib.googlecode.com/hg/README.html">plume-lib</a>,
 * which contains a variety of useful programs and libraries; for more
 * details, please see the
 * <a href="http://plume-lib.googlecode.com/hg/README.html">plume-lib
 * documentation</a>.
 * </p>
 */

package plume;
